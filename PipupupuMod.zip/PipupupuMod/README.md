# PipupupuMod
Changes the Hoarding Bug chitter SFX to the 'pipupupu' sound.
# Manual Installation
1. Install BepInEx
2. Extract PipupupuMod.dll and pipupupusound into the plugins folder of BepInEx
